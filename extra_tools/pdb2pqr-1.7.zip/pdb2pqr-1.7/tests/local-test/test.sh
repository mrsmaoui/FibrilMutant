PY_PATH=/usr/bin/python
SRCDIR=/scratch/msmaoui/pdb2pqr-1.7 
echo ----------------------------------------------------------------------------------
echo This is a local command line test.  Running pdb2pqr with forcefield=AMBER and path=1AFS.pdb
$PY_PATH $SRCDIR/pdb2pqr.py --ff=AMBER $SRCDIR/tests/local-test/1AFS.pdb $SRCDIR/tests/local-test/test-output-user.pqr

CWD=$SRCDIR/tests/local-test
$CWD/localtest

