#! /usr/bin/env python
"""WSDL parsing services package for Web Services for Python."""

ident = "$Id: __init__.py 840 2004-12-07 15:54:53Z blunck2 $"

import WSDLTools
import XMLname
import logging

